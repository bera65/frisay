/**
 * Trendyol admin: marka / kategori arama seçicileri + özellik formu
 */
(function (window, document) {
	'use strict';

	var timers = {};

	function esc(s) {
		return String(s == null ? '' : s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function apiUrl(key) {
		if (key === 'brands') return window.trendyolBrandsApiUrl || '';
		if (key === 'categories') return window.trendyolCategoriesApiUrl || '';
		if (key === 'attributes') return window.trendyolAttributesApiUrl || '';
		return '';
	}

	function getJson(url) {
		return fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.json(); });
	}

	function debounce(key, fn, ms) {
		if (timers[key]) clearTimeout(timers[key]);
		timers[key] = setTimeout(fn, ms || 400);
	}

	function findPicker(el) {
		return el.closest('.ty-picker');
	}

	function setSelected(picker, id, label) {
		var idInput = picker.querySelector('.ty-picker-id');
		var nameInput = picker.querySelector('.ty-picker-name');
		var labelEl = picker.querySelector('.ty-picker-selected');
		var query = picker.querySelector('.ty-picker-query');
		var results = picker.querySelector('.ty-picker-results');

		if (idInput) idInput.value = id || '';
		if (nameInput) nameInput.value = label || '';
		if (labelEl) {
			if (id) {
				labelEl.innerHTML = '<span class="badge text-bg-success">' + esc(label || ('#' + id)) + '</span>' +
					' <span class="text-muted small">#' + esc(id) + '</span>';
			} else {
				labelEl.innerHTML = '<span class="text-muted small">Seçilmedi</span>';
			}
		}
		if (query) query.value = '';
		if (results) results.innerHTML = '';

		picker.dispatchEvent(new CustomEvent('ty:selected', {
			bubbles: true,
			detail: { id: id, label: label, type: picker.getAttribute('data-type') }
		}));
	}

	function renderResults(picker, items, type) {
		var results = picker.querySelector('.ty-picker-results');
		if (!results) return;

		if (!items.length) {
			results.innerHTML = '<div class="text-muted small p-2">Sonuç yok</div>';
			return;
		}

		var html = '<div class="list-group list-group-flush border rounded ty-picker-list">';
		items.forEach(function (item) {
			html += '<button type="button" class="list-group-item list-group-item-action ty-picker-item"' +
				' data-id="' + esc(item.id) + '" data-label="' + esc(item.label) + '">' +
				'<div class="fw-semibold small">' + esc(item.label) + '</div>' +
				'<div class="text-muted" style="font-size:11px">#' + esc(item.id) + '</div>' +
				'</button>';
		});
		html += '</div>';
		results.innerHTML = html;
	}

	function searchPicker(picker) {
		var type = picker.getAttribute('data-type');
		var queryEl = picker.querySelector('.ty-picker-query');
		var results = picker.querySelector('.ty-picker-results');
		var q = queryEl ? queryEl.value.trim() : '';

		if (!results) return;

		if (q.length < 2) {
			results.innerHTML = '<div class="text-muted small p-1">En az 2 karakter yazın…</div>';
			return;
		}

		var base = apiUrl(type === 'brand' ? 'brands' : 'categories');
		if (!base) {
			results.innerHTML = '<div class="text-danger small p-1">API adresi yok</div>';
			return;
		}

		results.innerHTML = '<div class="text-muted small p-1">Aranıyor…</div>';
		var sep = base.indexOf('?') >= 0 ? '&' : '?';

		getJson(base + sep + 'name=' + encodeURIComponent(q))
			.then(function (res) {
				if (!res.success) {
					results.innerHTML = '<div class="text-danger small p-1">' + esc(res.message || 'Hata') + '</div>';
					return;
				}

				var items = [];
				if (type === 'brand') {
					(res.brands || []).slice(0, 20).forEach(function (b) {
						var id = b.id || b.brandId || '';
						var name = b.name || b.brandName || '';
						if (id) items.push({ id: id, label: name || ('#' + id) });
					});
				} else {
					(res.categories || []).forEach(function (c) {
						items.push({
							id: c.id,
							label: c.path || c.name || ('#' + c.id)
						});
					});
				}

				renderResults(picker, items, type);
			})
			.catch(function () {
				results.innerHTML = '<div class="text-danger small p-1">İstek başarısız</div>';
			});
	}

	function collectAttributes(panel) {
		var hidden = panel.querySelector('.ty-attributes');
		var map = {};
		panel.querySelectorAll('.ty-attr-input').forEach(function (el) {
			var aid = el.getAttribute('data-attr-id');
			var val = (el.value || '').trim();
			if (aid && val !== '') map[aid] = val;
		});
		if (hidden) hidden.value = JSON.stringify(map);
		return map;
	}

	function renderAttributeForm(panel, categoryAttributes, selected) {
		var box = panel.querySelector('.ty-attr-form');
		var hidden = panel.querySelector('.ty-attributes');
		if (!box) return;

		selected = selected || {};
		if (hidden && hidden.value) {
			try {
				var parsed = JSON.parse(hidden.value);
				if (parsed && typeof parsed === 'object') {
					Object.keys(parsed).forEach(function (k) {
						if (selected[k] == null) selected[k] = parsed[k];
					});
				}
			} catch (e) { /* ignore */ }
		}

		if (!categoryAttributes || !categoryAttributes.length) {
			box.innerHTML = '<div class="text-muted small">Bu kategori için özellik listesi boş.</div>';
			return;
		}

		var html = '<div class="row g-2">';
		categoryAttributes.forEach(function (row) {
			var attr = row.attribute || {};
			var aid = attr.id;
			if (!aid) return;
			var aname = attr.name || ('#' + aid);
			var required = !!row.required;
			var allowCustom = !!row.allowCustom;
			var values = row.attributeValues || [];
			var cur = selected[String(aid)] != null ? selected[String(aid)] : '';

			html += '<div class="col-md-6"><label class="form-label small mb-0">' + esc(aname);
			if (required) html += ' <span class="text-danger">*</span>';
			html += '</label>';

			if (!allowCustom && values.length) {
				html += '<select class="form-select form-select-sm ty-attr-input" data-attr-id="' + esc(aid) + '">';
				html += '<option value="">Seçin…</option>';
				values.forEach(function (v) {
					var vid = v.id != null ? v.id : (v.attributeValueId != null ? v.attributeValueId : '');
					var vname = v.name || v.attributeValueName || ('#' + vid);
					var sel = String(cur) === String(vid) ? ' selected' : '';
					html += '<option value="' + esc(vid) + '"' + sel + '>' + esc(vname) + '</option>';
				});
				html += '</select>';
			} else {
				html += '<input type="text" class="form-control form-control-sm ty-attr-input" data-attr-id="' +
					esc(aid) + '" value="' + esc(cur) + '" placeholder="' + (allowCustom ? 'Serbest metin' : '') + '">';
			}
			html += '</div>';
		});
		html += '</div>';
		box.innerHTML = html;
		collectAttributes(panel);
	}

	function loadAttributesForPanel(panel, categoryId) {
		var box = panel.querySelector('.ty-attr-form');
		var url = apiUrl('attributes');
		if (!box || !url || !categoryId) return;

		box.innerHTML = '<div class="text-muted small">Özellikler yükleniyor…</div>';
		var sep = url.indexOf('?') >= 0 ? '&' : '?';

		getJson(url + sep + 'category_id=' + encodeURIComponent(categoryId))
			.then(function (res) {
				if (!res.success) {
					box.innerHTML = '<div class="text-danger small">' + esc(res.message || 'Özellikler alınamadı') + '</div>';
					return;
				}
				renderAttributeForm(panel, res.categoryAttributes || [], {});
			})
			.catch(function () {
				box.innerHTML = '<div class="text-danger small">Özellik isteği başarısız</div>';
			});
	}

	document.addEventListener('input', function (e) {
		var query = e.target.closest('.ty-picker-query');
		if (!query) return;
		var picker = findPicker(query);
		if (!picker) return;
		var key = picker.getAttribute('data-type') + ':' + (picker.getAttribute('data-key') || 'x');
		debounce(key, function () { searchPicker(picker); }, 350);
	});

	document.addEventListener('keydown', function (e) {
		if (e.key !== 'Enter') return;
		var query = e.target.closest('.ty-picker-query');
		if (!query) return;
		e.preventDefault();
		var picker = findPicker(query);
		if (picker) searchPicker(picker);
	});

	document.addEventListener('click', function (e) {
		var item = e.target.closest('.ty-picker-item');
		if (item) {
			var picker = findPicker(item);
			if (picker) {
				setSelected(picker, item.getAttribute('data-id'), item.getAttribute('data-label'));
			}
			return;
		}

		var clearBtn = e.target.closest('.ty-picker-clear');
		if (clearBtn) {
			var picker = findPicker(clearBtn);
			if (picker) setSelected(picker, '', '');
			return;
		}

		if (!e.target.closest('.ty-picker')) {
			document.querySelectorAll('.ty-picker-results').forEach(function (el) {
				if (el.innerHTML && !el.querySelector('.ty-picker-list') === false) {
					/* keep open if has list until outside click of results area handled below */
				}
			});
		}
	});

	document.addEventListener('ty:selected', function (e) {
		var picker = e.target.closest ? e.target.closest('.ty-picker') : null;
		if (!picker || e.detail.type !== 'category') return;
		var panel = picker.closest('.trendyol-product-panel, .ty-category-map-row, .admin-panel');
		if (!panel || !panel.querySelector('.ty-attr-form')) return;
		if (e.detail.id) loadAttributesForPanel(panel, e.detail.id);
	});

	document.addEventListener('change', function (e) {
		if (!e.target.classList.contains('ty-attr-input')) return;
		var panel = e.target.closest('.trendyol-product-panel, .ty-category-map-row, .admin-panel');
		if (panel) collectAttributes(panel);
	});

	document.addEventListener('input', function (e) {
		if (!e.target.classList.contains('ty-attr-input')) return;
		var panel = e.target.closest('.trendyol-product-panel, .ty-category-map-row, .admin-panel');
		if (panel) collectAttributes(panel);
	});

	function post(url, body) {
		return fetch(url, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			credentials: 'same-origin',
			body: new URLSearchParams(body).toString()
		}).then(function (r) { return r.json(); });
	}

	function panelMsg(panel, text, ok) {
		var el = panel.querySelector('.ty-action-msg');
		if (!el) return;
		el.textContent = text || '';
		el.className = 'small d-block mt-2 ty-action-msg ' + (ok ? 'text-success' : 'text-danger');
	}

	function bindProductActions() {
		document.querySelectorAll('.ty-sync-btn').forEach(function (btn) {
			if (btn.dataset.tyBound) return;
			btn.dataset.tyBound = '1';
			btn.addEventListener('click', function () {
				var panel = btn.closest('.trendyol-product-panel');
				if (panel) collectAttributes(panel);
				var body = { id_product: btn.getAttribute('data-id') };
				var brand = panel && panel.querySelector('.ty-brand-id');
				var cat = panel && panel.querySelector('.ty-category-id');
				var attrs = panel && panel.querySelector('.ty-attributes');
				var sale = panel && panel.querySelector('.ty-sale-price-input');
				var list = panel && panel.querySelector('.ty-list-price-input');
				if (brand && brand.value) body.brand_id = brand.value;
				if (cat && cat.value) body.category_id = cat.value;
				if (attrs && attrs.value) body.attributes = attrs.value;
				if (sale && sale.value !== '') body.sale_price = sale.value;
				if (list && list.value !== '') body.list_price = list.value;
				btn.disabled = true;
				panelMsg(panel, 'Gönderiliyor…', true);
				post(btn.getAttribute('data-url'), body)
					.then(function (res) {
						panelMsg(panel, res.message || '', !!res.success);
						if (res.success) setTimeout(function () { location.reload(); }, 800);
					})
					.catch(function () { panelMsg(panel, 'İstek başarısız', false); })
					.finally(function () { btn.disabled = false; });
			});
		});

		document.querySelectorAll('.ty-price-btn').forEach(function (btn) {
			if (btn.dataset.tyBound) return;
			btn.dataset.tyBound = '1';
			btn.addEventListener('click', function () {
				var panel = btn.closest('.trendyol-product-panel');
				var body = { id_product: btn.getAttribute('data-id') };
				var sale = panel && panel.querySelector('.ty-sale-price-input');
				var list = panel && panel.querySelector('.ty-list-price-input');
				if (sale && sale.value !== '') body.sale_price = sale.value;
				if (list && list.value !== '') body.list_price = list.value;
				btn.disabled = true;
				panelMsg(panel, 'Fiyat güncelleniyor…', true);
				post(btn.getAttribute('data-url'), body)
					.then(function (res) {
						panelMsg(panel, res.message || '', !!res.success);
						if (res.success && res.mapping) {
							var q = panel.querySelector('.ty-qty');
							if (q) q.textContent = res.mapping.quantity;
							if (sale) sale.value = res.mapping.sale_price;
							if (list) list.value = res.mapping.list_price;
						}
					})
					.catch(function () { panelMsg(panel, 'İstek başarısız', false); })
					.finally(function () { btn.disabled = false; });
			});
		});

		document.querySelectorAll('.ty-refresh-btn').forEach(function (btn) {
			if (btn.dataset.tyBound) return;
			btn.dataset.tyBound = '1';
			btn.addEventListener('click', function () {
				var panel = btn.closest('.trendyol-product-panel');
				btn.disabled = true;
				panelMsg(panel, 'Yenileniyor…', true);
				post(btn.getAttribute('data-url'), { id_product: btn.getAttribute('data-id') })
					.then(function (res) {
						panelMsg(panel, res.message || '', !!res.success);
						if (res.success) setTimeout(function () { location.reload(); }, 700);
					})
					.catch(function () { panelMsg(panel, 'İstek başarısız', false); })
					.finally(function () { btn.disabled = false; });
			});
		});

		document.querySelectorAll('.trendyol-product-panel').forEach(function (panel) {
			var catId = panel.querySelector('.ty-category-id');
			var form = panel.querySelector('.ty-attr-form');
			if (catId && catId.value && form && !form.dataset.loaded) {
				form.dataset.loaded = '1';
				loadAttributesForPanel(panel, catId.value);
			}
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bindProductActions);
	} else {
		bindProductActions();
	}

	window.TrendyolAdmin = {
		setSelected: setSelected,
		loadAttributesForPanel: loadAttributesForPanel,
		bindProductActions: bindProductActions
	};
})(window, document);
